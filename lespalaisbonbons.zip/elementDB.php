<?php

$table['gite'] = "()";
$table['sejour'] = "()";
$table['pays'] = "()";
$table['emplacement_geogprahique'] = "()";
$table['couchage'] = "()";
$table['sdb'] = "()";
$table['photo'] = "()";
$table["categorie"] = "()";