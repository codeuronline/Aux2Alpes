<?php 
$db = null;
?>